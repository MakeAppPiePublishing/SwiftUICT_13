//
//  ViewController.swift
//  HelloSUIPizza
//
//  Created by Steven Lipton on 2/26/25.
//

import UIKit
import SwiftUI

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBSegueAction func HelloSegue(_ coder: NSCoder) -> UIViewController? {
        return UIHostingController(coder: coder, rootView: SwiftUIHelloPizzaView())
    }
}

