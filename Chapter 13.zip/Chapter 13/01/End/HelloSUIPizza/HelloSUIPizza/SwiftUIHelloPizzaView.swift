//
//  SwiftUIHelloPizzaView.swift
//  HelloSUIPizza
//
//  Created by Steven Lipton on 2/26/25.
//

import SwiftUI

struct SwiftUIHelloPizzaView: View {
    var body: some View {
        List(1...10,id:\.self){ i in
            Text(i,format:.number)
                .font(.title)
        }
    }
}

#Preview {
    SwiftUIHelloPizzaView()
}
