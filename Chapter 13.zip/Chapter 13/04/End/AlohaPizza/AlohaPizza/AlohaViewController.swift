//
//  AlohaViewController.swift
//  AlohaPizza
//
//  Created by Steven Lipton on 2/26/25.
//

import UIKit

protocol AlohaViewControllerDelegate{
    func buttonStateChanged(buttonState:Bool)
}



class AlohaViewController:UIViewController{
    var alohaState =  false
    var delegate:AlohaViewControllerDelegate! = nil
    // Add UIKit views here as initialized variables, set them up in viewDidLoad
    var label = UILabel()
    var titleLabel =  UILabel()
    var button = UIButton()
    
    @IBAction func helloButton(sender: UIButton){
        alohaState.toggle()
        delegate.buttonStateChanged(buttonState: alohaState)
        if alohaState{
            label.text = "Eat More Ono Pizza"
            button.setTitle("Aloha", for: .normal)
        } else {
            label.text = "Aloha Pizza"
            button.setTitle("Eat", for: .normal)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//Configuring my UI here using the extensions found below
        titleLabel = UILabel.Label(
            text: "UIKit / SwiftUIDemo",
            font: .title1
        )
        label = UILabel.Label(
            text: "Aloha Pizza",
            font:.title1)
        button = UIButton.Button(
            title: "Hello",
            target: self,
            selector: #selector(helloButton(sender:)),
            font: .title1,
            textColor: .white,
            backgroundColor: .red
        )
        //Set up a Vstack to contain the views above
        let rootStack = UIStackView.VStack(views:[
            titleLabel,
            label,
            button
        ],alignment: .fill,spacing: 10)
        // Embed the stack in self.view
        UIStackView.embed(stack: rootStack, in: self.view)
        self.view.backgroundColor = .secondarySystemBackground
    }
}




/*
---------------------------------------------
 Extensions
 
 These extensions mimic SwiftUI in UIKit. Use them to make quick layouts in code for
--------------------------------------------
*/

// An exercise file for iOS Development Tips Weekly
// A weekely course on LinkedIn Learning for iOS developers
//  Season 10 (Q2 2020) video 04
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
// This Week:  Explore extentions and customizing your UI when prototyping using a fake SwiftUI StackView based on UIStackView.
//  For more code, go to http://bit.ly/AppPieGithub
// Modified 1/16/2025 for use in SwiftUI Completele training Chapter 12 SJL
//  -- Added comments and changed the views
//  -- Changed this to a single file for ease of import for a UIViewRepresentable and UIViewController Representable.
//  -- Added spacing parameter to the stacks



/// UIButton.Button
/// - An extension to `UIButton` to make a quick styled button.
public extension UIButton{
    class func Button(title:String, target:Any? , selector:Selector, font:UIFont.TextStyle = . body, textColor:UIColor = .blue, backgroundColor:UIColor = .clear) -> UIButton{
        let button = UIButton()
        button.addTarget(target, action: selector, for:.touchUpInside)
        button.setTitle(title, for: .normal)
        button.setTitleColor(textColor, for: .normal)
        button.backgroundColor = backgroundColor
        button.titleLabel?.font = UIFont.preferredFont(forTextStyle: font)
        return button
    }
}


/// UILabel.Label
/// - An Extension to `UILabel` to make a quick styled label

public extension UILabel{
    class func Label(text:String,font:UIFont.TextStyle = .body, textColor:UIColor = .label, backgroundColor:UIColor = .clear, alignment:NSTextAlignment = .natural)->UILabel{
        let label = UILabel()
        label.text = text
        label.font = UIFont.preferredFont(forTextStyle: font)
        label.textColor = textColor
        label.backgroundColor = backgroundColor
        label.textAlignment = alignment
        return label
    }
}


public extension UIStackView{
    
    /// UIStackView.Vstack
    ///  - A imitation of the SwiftUI `VStack` view using an array of UIViews. Use this for quick layout in UIKIt in code, especially in Swift Playgrounds.  For a root view, use this and the `embed` in the `view` property  of a view controller.
    class func VStack(views:[UIView], alignment:UIStackView.Alignment = .fill,spacing:CGFloat = 0.0)->UIStackView{
        let stack = UIStackView(arrangedSubviews: views)
        stack.axis = .vertical
        stack.alignment = alignment
        stack.distribution = .fillEqually
        stack.spacing = spacing
        return stack
    }
    
    /// UIStackView.Hstack
    ///  - A imitation of the SwiftUI `HStack` view using an array of UIViews. Use this for quick layout in UIKIt in code, especially in Swift Playgrounds.  For a root view, Embed this in the `view` property  of a view controller.
    class func HStack(views:[UIView],alignment:UIStackView.Alignment = .fill, spacing:CGFloat = 0.0)->UIStackView{
        let stack = UIStackView(arrangedSubviews: views)
        stack.axis = .horizontal
        stack.alignment = alignment
        stack.distribution = .fillEqually
        stack.spacing = spacing
        return stack
    }
    /// UIStackView.embed
    /// - An extension to add  a `UIStackView` that fits in a specified view with the specified padding. Especially useful for embedding a `UIStackView` in a `UIViewController.view` and thus simulating SwiftUI when you dont want to work with Autolayout in your code, or using a Storyboard.
    class func embed(stack:UIStackView, in view:UIView, padding:CGFloat = 0.0){
        view.addSubview(stack)
        //Prepare for Autolayout
        stack.translatesAutoresizingMaskIntoConstraints = false
        var constraints = [NSLayoutConstraint]()
        
        // set the constraints programatically
        
        // top with an offset of `padding`
        constraints += [NSLayoutConstraint(item: stack, attribute: .top, relatedBy: .equal, toItem: view, attribute: .top, multiplier: 1.0, constant: padding)]
        
        // bottom with an offset of `padding`
        constraints += [NSLayoutConstraint(item: stack, attribute: .bottom, relatedBy: .equal, toItem: view, attribute: .bottom, multiplier: 1.0, constant: padding)]
        // leading side with tan offset of `padding
        constraints += [NSLayoutConstraint(item: stack, attribute: .leading, relatedBy: .equal, toItem: view, attribute: .leading, multiplier: 1.0, constant: padding)]
        
        // trailing with an offset of `.padding`
        constraints += [NSLayoutConstraint(item: stack, attribute: .trailing, relatedBy: .equal, toItem: view, attribute: .trailing, multiplier: 1.0, constant: padding)]
        
        // Add the constraints
        view.addConstraints(constraints)
    }
}


