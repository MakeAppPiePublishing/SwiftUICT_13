//
//  ContentView.swift
//  AlohaPizza
//
//  Created by Steven Lipton on 1/17/25.
//

import SwiftUI

struct ContentView: View {
    @State var eatState:Bool = false
    var body: some View {
        VStack {
            Text(eatState ? "I'm Hungry!" : "Hello, world!")
                .font(.title)
            Divider()
            HStack{
                Text("AlohaViewController").font(.caption)
                Spacer()
            }
            AlohaPizzaView(buttonState: $eatState)
                .clipShape(RoundedRectangle(cornerRadius: 20))
            Divider()
            Spacer()
            Button(eatState ?  "Aloha": "Eat"){
                eatState.toggle()
            }
            .font(.title)
            .foregroundStyle(.primary)
            .padding(40)
            .background(.green, in:Circle())
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
