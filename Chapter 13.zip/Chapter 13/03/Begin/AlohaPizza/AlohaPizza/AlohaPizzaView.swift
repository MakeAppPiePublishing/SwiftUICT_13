//
//  AlohaPizzaView.swift
//  AlohaPizza
//
//  Created by Steven Lipton on 2/26/25.
//

import SwiftUI

struct AlohaPizzaView:UIViewControllerRepresentable{
    func makeUIViewController(context:Context) -> AlohaViewController{
        let vc = AlohaViewController()
        return vc
    }
    
    func updateUIViewController(_ uiViewController: AlohaViewController, context:Context){
        
    }
    
}
