//
//  AlohaPizzaApp.swift
//  AlohaPizza
//
//  Created by Steven Lipton on 2/26/25.
//

import SwiftUI

@main
struct AlohaPizzaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
